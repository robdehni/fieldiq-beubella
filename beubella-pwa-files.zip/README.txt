BEU BELLA PWA FILES

Upload these files to the ROOT of the fieldiq-beubella GitHub repository:
- manifest.json
- sw.js
- icon-180.png
- icon-192.png
- icon-512.png
- icon-512-maskable.png

Your current index.html already contains:
<link rel="manifest" href="./manifest.json">
<link rel="apple-touch-icon" href="./icon-180.png">
navigator.serviceWorker.register("./sw.js", { updateViaCache: "none" })

So do not replace index.html.

After upload:
1. Wait for GitHub Pages deployment to finish.
2. On Android Chrome, clear site data for beubella.fieldiq.biz.
3. Reopen https://beubella.fieldiq.biz
4. Chrome menu should show Install app rather than only Create shortcut.
